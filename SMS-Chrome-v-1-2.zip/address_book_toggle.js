// Toggle address book to open and close when clicking on the icon
$("img").click(function () {
$("textarea").toggle();
});
$("h1").click(function () {
$("textarea").toggle();
});